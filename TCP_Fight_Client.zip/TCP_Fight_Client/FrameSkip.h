#pragma once
class CFrameSkip
{
public:
	CFrameSkip() = default;
	CFrameSkip(int _MaxFrameTime);
	~CFrameSkip() = default;
	bool FrameSkip(HWND hWnd);
private:
	DWORD		_MaxFrameTime;
	DWORD		_OneFrameTime = 0;
};

