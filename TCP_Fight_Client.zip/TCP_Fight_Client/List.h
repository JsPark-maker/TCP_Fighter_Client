#pragma once
#pragma once
template <typename T>
class CList
{
public:
	struct Node
	{
		T _data;
		Node* _Next;
		Node* _Pre;
	};

	class iterator
	{
	private:
		Node* _node;

	public:
		iterator(Node* node = nullptr)
		{
			_node = node;
		}

		const iterator operator ++(int)
		{
			const iterator tmp = *this;
			_node = _node->_Next;
			return tmp;
		}

		iterator& operator ++()
		{
			_node = _node->_Next;
			return *this;
		}

		const iterator operator --(int)
		{
			const iterator tmp = *this;
			_node = _node->_Pre;
			return tmp;
		}

		iterator& operator --()
		{
			_node = _node->_Pre;
			return *this;
		}

		Node* operator ->() const
		{
			return _node;
		}

		T& operator *() const
		{
			return _node->_data;
		}

		/*const T& operator *() const
		{
			return _node->_data;
		}*/

		bool operator != (const iterator& other) const
		{
			return !(_node == other._node);
		}
	};

public:
	CList()
	{
		_head._data = 0;
		_head._Next = &_tail;
		_head._Pre = nullptr;

		_tail._data = 0;
		_tail._Next = nullptr;
		_tail._Pre = &_head;
	}

	~CList()
	{
		clear();
	}

	iterator begin()
	{
		return iterator(_head._Next);
	}

	iterator end()
	{
		return iterator(&_tail);
	}

	void push_front(T data)
	{
		Node* newnode = new Node;
		newnode->_Next = _head._Next;
		_head._Next->_Pre = newnode;
		_head._Next = newnode;

		newnode->_data = data;
		newnode->_Pre = &_head;

		++_size;
	}

	void push_back(T data)
	{
		Node* newnode = new Node;
		newnode->_data = data;
		newnode->_Next = &_tail;
		newnode->_Pre = _tail._Pre;

		_tail._Pre->_Next = newnode;
		_tail._Pre = newnode;
	}

	int size() const
	{
		return _size;
	}

	bool empty() const
	{
		if (_head._Next == &_tail)
			return true;
		else
			return false;
	};

	//T pop_front();
	//T pop_back();

	void clear()
	{
		for (Node* currNode = _head._Next; currNode != &_tail;)
		{
			Node* NextNode = currNode->_Next;
			delete currNode;
			currNode = NextNode;
		}
	}

	iterator erase(iterator iter)
	{
		--_size;

		iterator Nextiter = iter->_Next;

		Node* currNode = iter->_Pre->_Next;

		iter->_Pre->_Next = iter->_Next;
		iter->_Next->_Pre = iter->_Pre;

		delete currNode;
		return Nextiter;
	}

private:
	int _size = 0;
	Node _head;
	Node _tail;
};
