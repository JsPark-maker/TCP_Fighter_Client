#include "SpriteInfo.h"

CSpriteInfo::CSpriteInfo(int spriteStart, int spriteEnd, int spriteDelay)
	:_spriteStart(spriteStart), _spriteEnd(spriteEnd), _spriteDelay(spriteDelay)
{}
