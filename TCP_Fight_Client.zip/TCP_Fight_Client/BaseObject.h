#pragma once

class CSpriteInfo;

class CBaseObject abstract
{
protected:
	bool	_endFrame = true;
	DWORD   _actionInput = 12;

	int		_curX;
	int		_curY;

	int		_delayCount;
	int		_frameDelay;

	int		_objectID;
	int		_objectType;

	int		_spriteStart;
	int		_spriteNow;
	int		_spriteEnd;

	bool	isHit = false;

public:
	// =====================
	// ������
	// =====================
	CBaseObject() = default;
	CBaseObject(int id, unsigned short X, unsigned short Y);

	// =====================
	// �Ҹ���
	// =====================
	virtual ~CBaseObject() = default;

	void ActionInput(DWORD action);

	int GetCurX();

	int GetCurY();

	int GetObjectID();

	int GetObjectType();

	int GetSprite();

	bool IsEndFrame();

	void NextFrame();

	virtual void Render(BYTE* pDest, int DestWidth, int DestHeight, int DestPitch) = 0;

	virtual void Update() = 0;

	void SetPosition(int curX, int curY);

	void SetSprite(CSpriteInfo spriteInfo, int dir);

	void MakeHitTrue();

	void MakeHitFalse();

	bool GetHitFlag();

	DWORD GetActionInput();
};

