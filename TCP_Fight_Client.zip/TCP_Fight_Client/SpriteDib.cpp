#include "framework.h"

CSpriteDib::CSpriteDib(int MaxSprite, DWORD ColorKey)
	:_MaxSprite(MaxSprite), _ColorKey(ColorKey), _stpSprite(nullptr)
{
	_stpSprite = new _stSprite[_MaxSprite];
	memset(_stpSprite, 0, sizeof(_stSprite) * _MaxSprite);
}

CSpriteDib::~CSpriteDib()
{
	for (int Count = 0; Count < _MaxSprite; Count++)
	{
		ReleaseSprite(Count);
	}

	delete[] _stpSprite;
}

BOOL CSpriteDib::LoadDibSprite(int SpriteIndex, const char* FileName, int CenterPointX, int CenterPointY)
{
	FILE*			 pFile;
	BITMAPFILEHEADER stBitMapFileHeader;
	BITMAPINFOHEADER stBitMapInfoHeader;

	fopen_s(&pFile, FileName, "rb");

	ReleaseSprite(SpriteIndex);

	// ���� ��� �б�
	fread(&stBitMapFileHeader, sizeof(BITMAPFILEHEADER), 1, pFile);
	fread(&stBitMapInfoHeader, sizeof(BITMAPINFOHEADER), 1, pFile);
	fseek(pFile, stBitMapFileHeader.bfOffBits, SEEK_SET);

	int Pitch = (stBitMapInfoHeader.biWidth * (stBitMapInfoHeader.biBitCount / 8)) + 3 & ~3;

	// Sprite ����ü ����
	_stpSprite[SpriteIndex]._BitColor = stBitMapInfoHeader.biBitCount;
	_stpSprite[SpriteIndex]._Width = stBitMapInfoHeader.biWidth;
	_stpSprite[SpriteIndex]._Height = stBitMapInfoHeader.biHeight;
	_stpSprite[SpriteIndex]._Pitch = Pitch;
	_stpSprite[SpriteIndex]._Size = _stpSprite[SpriteIndex]._Height * Pitch;
	_stpSprite[SpriteIndex]._pBitMapImage = new BYTE[_stpSprite[SpriteIndex]._Size];
	_stpSprite[SpriteIndex]._CenterPointX = CenterPointX;
	_stpSprite[SpriteIndex]._CenterPointY = CenterPointY;

	// �ӽ� �̹��� ���� ����
	BYTE* pTempBuffer = new BYTE[_stpSprite[SpriteIndex]._Size];
	// ���� �̹��� ����.
	BYTE* SpriteTemp = _stpSprite[SpriteIndex]._pBitMapImage;
	// �ǹ��� ����ų ������
	BYTE* pTurnTemp;

	fread(pTempBuffer, _stpSprite[SpriteIndex]._Size, 1, pFile);

	pTurnTemp = pTempBuffer + (Pitch * (_stpSprite[SpriteIndex]._Height - 1));
	
	for (int i = 0; i < _stpSprite[SpriteIndex]._Height; i++)
	{
		memcpy(SpriteTemp, pTurnTemp, Pitch);
		SpriteTemp += Pitch;
		pTurnTemp -= Pitch;
	}
	delete[] pTempBuffer;

	fclose(pFile);

	return true;
}

void CSpriteDib::ReleaseSprite(int SpriteIndex)
{
	if (_MaxSprite <= SpriteIndex)
		return;

	if (nullptr != _stpSprite[SpriteIndex]._pBitMapImage)
	{
		delete[] _stpSprite[SpriteIndex]._pBitMapImage;
		memset(&_stpSprite[SpriteIndex], 0, sizeof(_stSprite));
	}
}

void CSpriteDib::DrawSprite(int SpriteIndex, int DrawX, int DrawY, BYTE* pDest, int DestWidth, int DestHeight, int DestPitch, int DrawLen)
{
	if (SpriteIndex >= _MaxSprite)
		return;

	if (nullptr == _stpSprite[SpriteIndex]._pBitMapImage)
		return;

	_stSprite* stpSprite = &_stpSprite[SpriteIndex];

	int SpriteWidth = stpSprite->_Width;
	int SpriteHeight = stpSprite->_Height;

	SpriteWidth = SpriteWidth * DrawLen / 100;

	DWORD* dwpDest = (DWORD*)pDest;
	DWORD* dwpSprite = (DWORD*)(stpSprite->_pBitMapImage);

	DrawX = DrawX - stpSprite->_CenterPointX;
	DrawY = DrawY - stpSprite->_CenterPointY;

	if (0 > DrawY)
	{
		SpriteHeight = SpriteHeight - (-DrawY);
		dwpSprite = (DWORD*)(stpSprite->_pBitMapImage + stpSprite->_Pitch * (-DrawY));
		DrawY = 0;
	}

	if (DestHeight < DrawY + stpSprite->_Height)
	{
		SpriteHeight -= ((DrawY + stpSprite->_Height) - DestHeight);
	}

	if (0 > DrawX)
	{
		SpriteWidth = SpriteWidth - (-DrawX);
		dwpSprite = dwpSprite + (-DrawX);
		DrawX = 0;
	}

	if (DestWidth <= DrawX + stpSprite->_Width)
	{
		SpriteWidth -= ((DrawX + stpSprite->_Width) - DestWidth);
	}

	if (SpriteWidth <= 0 || SpriteHeight <= 0)
		return;

	dwpDest = (DWORD*)((BYTE*)(dwpDest + DrawX) + (DrawY * DestPitch));

	BYTE* pDestOrigin = (BYTE*)dwpDest;
	BYTE* pSpriteOrigin = (BYTE*)dwpSprite;

	for (int CountY = 0; CountY < SpriteHeight; CountY++)
	{
		for (int CountX = 0; CountX < SpriteWidth; CountX++)
		{
			if (_ColorKey != (*dwpSprite & 0x00ffffff))
			{
				*dwpDest = *dwpSprite;
			}
			dwpDest++;
			dwpSprite++;
		}
		pDestOrigin = pDestOrigin + DestPitch;
		pSpriteOrigin = pSpriteOrigin + stpSprite->_Pitch;

		dwpDest = (DWORD*)pDestOrigin;
		dwpSprite = (DWORD*)pSpriteOrigin;
	}
}

void CSpriteDib::DrawImage(int SpriteIndex, int DrawX, int DrawY, BYTE* pDest, int DestWidth, int DestHeight, int DestPitch, int DrawLen)
{
	if (SpriteIndex >= _MaxSprite)
		return;

	if (nullptr == _stpSprite[SpriteIndex]._pBitMapImage)
		return;

	_stSprite* stpSprite = &_stpSprite[SpriteIndex];

	int SpriteWidth = stpSprite->_Width;
	int SpriteHeight = stpSprite->_Height;

	SpriteWidth = SpriteWidth * DrawLen / 100;

	DWORD* dwpDest = (DWORD*)pDest;
	DWORD* dwpSprite = (DWORD*)(stpSprite->_pBitMapImage);

	DrawX = DrawX - stpSprite->_CenterPointX;
	DrawY = DrawY - stpSprite->_CenterPointY;

	if (0 > DrawY)
	{
		SpriteHeight = SpriteHeight - (-DrawY);
		dwpSprite = (DWORD*)(stpSprite->_pBitMapImage + stpSprite->_Pitch * (-DrawY));
		DrawY = 0;
	}

	if (DestHeight < DrawY + stpSprite->_Height)
	{
		SpriteHeight -= ((DrawY + stpSprite->_Height) - DestHeight);
	}

	if (0 > DrawX)
	{
		SpriteWidth = SpriteWidth - (-DrawX);
		dwpSprite = dwpSprite + (-DrawX);
		DrawX = 0;
	}

	if (DestWidth <= DrawX + stpSprite->_Width)
	{
		SpriteWidth -= ((DrawX + stpSprite->_Width) - DestWidth);
	}

	if (SpriteWidth <= 0 || SpriteHeight <= 0)
		return;

	dwpDest = (DWORD*)((BYTE*)(dwpDest + DrawX) + (DrawY * DestPitch));

	BYTE* pDestOrigin = (BYTE*)dwpDest;
	BYTE* pSpriteOrigin = (BYTE*)dwpSprite;

	for (int CountY = 0; CountY < SpriteHeight; CountY++)
	{
		for (int CountX = 0; CountX < SpriteWidth; CountX++)
		{
			if (_ColorKey != (*dwpSprite & 0x00ffffff))
			{
				*dwpDest = *dwpSprite;
			}
			dwpDest++;
			dwpSprite++;
		}
		pDestOrigin = pDestOrigin + DestPitch;
		pSpriteOrigin = pSpriteOrigin + stpSprite->_Pitch;

		dwpDest = (DWORD*)pDestOrigin;
		dwpSprite = (DWORD*)pSpriteOrigin;
	}
}


