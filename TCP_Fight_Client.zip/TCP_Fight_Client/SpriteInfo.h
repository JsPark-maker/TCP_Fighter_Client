#pragma once
class CSpriteInfo
{
public:
	CSpriteInfo() = default;
	CSpriteInfo(int spriteStart, int spriteEnd, int spriteDelay);	

	int _spriteStart;
	int _spriteEnd;
	int _spriteDelay;

};

