#include "framework.h"
#include "Queue.h"
#include "SpriteDib.h"
#include "ScreenDibBuffer.h"

#include "BaseObject.h"
#include "CEffectObject.h"

CEffectObject::CEffectObject(int X, int Y, bool isLateEffect)
{
	_spriteStart = 128;
	_spriteNow = 128;
	_spriteEnd = 131;
	_frameDelay = 4;
	_delayCount = 0;
	lateDelayCount = 0;
	_endFrame = false;
	this->X = X;
	this->Y = Y;
	this->isLateEffect = isLateEffect;
}

void CEffectObject::Render(BYTE* pDest, int DestWidth, int DestHeight, int DestPitch)
{
	if (lateDelayCount < 12 && isLateEffect == true)
		return;

	SpriteDib.DrawSprite(GetSprite(), X, Y, pDest, DestWidth, DestHeight, DestPitch);
}

void CEffectObject::Update()
{
	if (lateDelayCount < 12 && isLateEffect == true)
	{
		lateDelayCount++;
		return;
	}

	NextFrame();
}
