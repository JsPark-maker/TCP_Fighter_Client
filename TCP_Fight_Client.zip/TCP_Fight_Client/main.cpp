﻿
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS

#include "framework.h"
#include "FrameSkip.h"
#include "SpriteInfo.h"
#include "BaseObject.h"
#include "PlayerObject.h"
#include "CEffectObject.h"

#define MAX_LOADSTRING 100
#define VK_Z 0x5A
#define VK_X 0x58
#define VK_C 0x43
#define SERVERIP L"127.0.0.1"
#define SERVERPORT 5000
#define WM_SELECT (WM_USER + 1)


HINSTANCE			g_hInst;
HWND				g_hWnd;
WCHAR				szTitle[MAX_LOADSTRING] = L"DibBuffer";
WCHAR				szWindowClass[MAX_LOADSTRING] = L"Class";

CFrameSkip frameObject = CFrameSkip(20);

CScreenDibBuffer	ScreenDibBuffer = CScreenDibBuffer(640, 480, 32);
CSpriteDib			SpriteDib = CSpriteDib(1000, 0x00ffffff);
GameState			State = Game;
bool				g_ActiveApp;

//네트워크용 전역변수
bool				g_IsConnect;
bool				g_SendFlag = true;
CRingBuffer			g_SendQueue;
CRingBuffer			g_RecvQueue;
SOCKET				g_Socket;

// 애니메이션 객체 배열
CSpriteInfo SpriteInfoArr[20];

CBaseObject* g_pPlayerObject;

CList<CBaseObject*> g_ObjectList;
CList<CBaseObject*> g_EffectList;
CList<CBaseObject*>::iterator iter;
CList<CBaseObject*>::iterator iter2;

ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);

void				InitialGame(void);

void				Update_Main(void);
void				Update_Title(void);
void				Update_Game(void);
void				Update(void);
void				SortObject();
void				KeyProcess(void);
void				Render();
void				MakeConsole();
void				ReadEvent();
void				SendEvent();
void				WriteEvent();
void				PacketProc(int, char*);
void				NetPacketProc_CreateMyCharacter(char*);
void				NetPacketProc_CreateOtherCharacter(char*);
void				NetPacketProc_DeleteCharacter(char*);
void				NetPacketProc_SC_MoveStart(char*);
void				NetPacketProc_SC_MoveStop(char*);
void				NetPacketProc_SC_Attack1(char*);
void				NetPacketProc_SC_Attack2(char*);
void				NetPacketProc_SC_Attack3(char*);
void				NetPacketProc_Damage(char*);
void				NetPacketProc_Sync(char*);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPWSTR    lpCmdLine,
	_In_ int       nCmdShow)
{
	InitialGame();
	MyRegisterClass(hInstance);
	InitInstance(hInstance, nCmdShow);
	MakeConsole();

	MSG msg;
	timeBeginPeriod(1);

	//다이알로그 생성하기
	int retVal;

	WSADATA wsa;

	WSAStartup(MAKEWORD(2, 2), &wsa);

	g_Socket = socket(AF_INET, SOCK_STREAM, NULL);

	WSAAsyncSelect(g_Socket, g_hWnd, WM_SELECT, FD_CONNECT | FD_READ | FD_WRITE | FD_CLOSE);

	SOCKADDR_IN clientAddr;
	clientAddr.sin_family = AF_INET;
	clientAddr.sin_port = htons(SERVERPORT);
	InetPton(AF_INET, SERVERIP, &clientAddr.sin_addr);

	retVal = connect(g_Socket, (SOCKADDR*)&clientAddr, sizeof(clientAddr));

	while (1)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			if (msg.message == WM_QUIT)
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
			if(g_IsConnect)
			Update_Main();
	}
	timeEndPeriod(1);
	return (int)msg.wParam;
}
//클래스 등록
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEXW wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_DIBBUFERR));
	wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_DIBBUFERR);
	wcex.lpszClassName = szWindowClass;
	wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassExW(&wcex);
}
//창 맞추기
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	g_hInst = hInstance; // 인스턴스 핸들을 전역 변수에 저장합니다.

	g_hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
		0, 0, 640, 480, nullptr, nullptr, hInstance, nullptr);

	if (!g_hWnd)
	{
		return FALSE;
	}

	ShowWindow(g_hWnd, nCmdShow);
	UpdateWindow(g_hWnd);

	RECT WindowRect;
	WindowRect.top = 0;
	WindowRect.left = 0;
	WindowRect.right = 640;
	WindowRect.bottom = 480;

	AdjustWindowRect(&WindowRect, GetWindowStyle(g_hWnd), GetMenu(g_hWnd) != NULL);

	int X = (GetSystemMetrics(SM_CXSCREEN) / 2) - (640 / 2);
	int Y = (GetSystemMetrics(SM_CYSCREEN) / 2) - (480 / 2);

	MoveWindow(g_hWnd, X, Y, WindowRect.right - WindowRect.left, WindowRect.bottom - WindowRect.top, true);

	return TRUE;
}
//메인윈도우 프로시저
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_SELECT:
		if (WSAGETSELECTERROR(lParam))
		{
			printf("WSAGETSELECTERROR\n");
			g_IsConnect = false;
			closesocket(wParam);
		}
		else
		{
			switch (WSAGETSELECTEVENT(lParam))
			{
			case FD_CONNECT:
				g_IsConnect = true;
				printf("서버랑 connect 했습니다.\n");
				break;
			case FD_READ:
				ReadEvent();
				break;
			case FD_WRITE:
				g_SendFlag = true;
				WriteEvent();
				break;
			case FD_CLOSE:
				break;
			}
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	case WM_ACTIVATEAPP:
		g_ActiveApp = (bool)wParam;
		break;

	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

void Update_Main(void)
{
	switch (State)
	{
	case Title:
		//아직 구현되지않음
		Update_Title();
		break;
	case Game:
		Update_Game();
		break;
	}
}

void Update_Title(void)
{}

void Update_Game(void)
{
	//창이 활성화 되있었을 경우에만 키 입력 받음
	if (g_ActiveApp)
		KeyProcess();

	Update();

	//프레임 스킵
	if (frameObject.FrameSkip(g_hWnd))
	{
		Render();

		ScreenDibBuffer.Flip(g_hWnd);
	}

	Sleep(0);
}

void KeyProcess(void)
{
	if (g_pPlayerObject == nullptr)
		return;

	int Action = ACTION_STAND;

	do
	{
		if (GetAsyncKeyState(VK_Z))
		{
			Action = ACTION_ATTACK1;
			break;
		}

		if (GetAsyncKeyState(VK_X))
		{
			Action = ACTION_ATTACK2;
			break;
		}

		if (GetAsyncKeyState(VK_C))
		{
			Action = ACTION_ATTACK3;
			break;
		}

		if (GetAsyncKeyState(VK_LEFT) && GetAsyncKeyState(VK_DOWN))
		{
			Action = ACTION_MOVE_LD;
			break;
		}

		if (GetAsyncKeyState(VK_LEFT) && GetAsyncKeyState(VK_UP))
		{
			Action = ACTION_MOVE_LU;
			break;
		}

		if (GetAsyncKeyState(VK_RIGHT) && GetAsyncKeyState(VK_DOWN))
		{
			Action = ACTION_MOVE_RD;
			break;
		}

		if (GetAsyncKeyState(VK_RIGHT) && GetAsyncKeyState(VK_UP))
		{
			Action = ACTION_MOVE_RU;
			break;
		}

		if (GetAsyncKeyState(VK_LEFT))
		{
			Action = ACTION_MOVE_LL;
			break;
		}

		if (GetAsyncKeyState(VK_RIGHT))
		{
			Action = ACTION_MOVE_RR;
			break;
		}

		if (GetAsyncKeyState(VK_UP))
		{
			Action = ACTION_MOVE_UU;
			break;
		}

		if (GetAsyncKeyState(VK_DOWN))
		{
			Action = ACTION_MOVE_DD;
			break;
		}
	} while (0);
	//입력을 받아 상태를 ActionInput으로 넣어준다.
	g_pPlayerObject->ActionInput(Action);
}

void Update()
{
	for (iter = g_ObjectList.begin(); iter != g_ObjectList.end(); iter++)
	{
		(*iter)->Update();
	}
	//객체 정렬
	for (CList<CBaseObject*>::iterator itor = g_EffectList.begin(); itor != g_EffectList.end();)
	{
		if (((CEffectObject*)itor->_data)->IsEndFrame() == false)
		{
			((CEffectObject*)itor->_data)->Update();
			itor++;
		}
		else
		{

			CList<CBaseObject*>::iterator itorBuffer = itor->_Next;
			g_EffectList.erase(itor);
			itor = itorBuffer;
		}
	}

	SortObject();
}

void SortObject()
{
	for (iter = g_ObjectList.begin(); iter != g_ObjectList.end(); iter++)
	{
		for (iter2 = g_ObjectList.begin(); iter2 != g_ObjectList.end()->_Pre; iter2++)
		{
			if ((*iter2)->GetCurY() > (iter2)->_Next->_data->GetCurY())
			{
				CBaseObject* ptr = iter2->_data;
				iter2->_data = iter2->_Next->_data;
				iter2->_Next->_data = ptr;
			}
		}
	}
}

void Render()
{
	BYTE* pBitMapImg = ScreenDibBuffer.GetScreenBuffer();
	int Height = ScreenDibBuffer.GetHieght();
	int Width = ScreenDibBuffer.GetWidth();
	int Pitch = ScreenDibBuffer.GetPitch();

	// 맵출력
	SpriteDib.DrawImage(0, 0, 0, pBitMapImg, Width, Height, Pitch);

	for (iter = g_ObjectList.begin(); iter != g_ObjectList.end(); iter++)
	{
		(*iter)->Render(pBitMapImg, Width, Height, Pitch);
	}

	for (CList<CBaseObject*>::iterator itor = g_EffectList.begin(); itor != g_EffectList.end();)
	{
		((CEffectObject*)itor->_data)->Render(pBitMapImg, Width, Height, Pitch);
		itor++;
		
	}
}

void InitialGame(void)
{
	SpriteDib.LoadDibSprite(SHADOW, "image/Shadow.bmp", 32, 4);
	SpriteDib.LoadDibSprite(GUAGE_HP, "image/HPGuage.bmp", 0, 0);

	SpriteDib.LoadDibSprite(0, "image/_Map.bmp", 0, 0);

	// ===========================================================
	// 기본 자세
	// ===========================================================
	SpriteDib.LoadDibSprite(1, "image/Stand_R_01.bmp", 71, 90);
	SpriteDib.LoadDibSprite(2, "image/Stand_R_02.bmp", 71, 90);
	SpriteDib.LoadDibSprite(3, "image/Stand_R_03.bmp", 71, 90);

	SpriteDib.LoadDibSprite(101, "image/Stand_L_01.bmp", 71, 90);
	SpriteDib.LoadDibSprite(102, "image/Stand_L_02.bmp", 71, 90);
	SpriteDib.LoadDibSprite(103, "image/Stand_L_03.bmp", 71, 90);

	SpriteDib.LoadDibSprite(4, "image/Move_R_01.bmp", 71, 90);
	SpriteDib.LoadDibSprite(5, "image/Move_R_02.bmp", 71, 90);
	SpriteDib.LoadDibSprite(6, "image/Move_R_03.bmp", 71, 90);
	SpriteDib.LoadDibSprite(7, "image/Move_R_04.bmp", 71, 90);
	SpriteDib.LoadDibSprite(8, "image/Move_R_05.bmp", 71, 90);
	SpriteDib.LoadDibSprite(9, "image/Move_R_06.bmp", 71, 90);
	SpriteDib.LoadDibSprite(10, "image/Move_R_07.bmp", 71, 90);
	SpriteDib.LoadDibSprite(11, "image/Move_R_08.bmp", 71, 90);
	SpriteDib.LoadDibSprite(12, "image/Move_R_09.bmp", 71, 90);
	SpriteDib.LoadDibSprite(13, "image/Move_R_10.bmp", 71, 90);
	SpriteDib.LoadDibSprite(14, "image/Move_R_11.bmp", 71, 90);
	SpriteDib.LoadDibSprite(15, "image/Move_R_12.bmp", 71, 90);

	// ===========================================================
	// 이동
	// ===========================================================
	SpriteDib.LoadDibSprite(104, "image/Move_L_01.bmp", 71, 90);
	SpriteDib.LoadDibSprite(105, "image/Move_L_02.bmp", 71, 90);
	SpriteDib.LoadDibSprite(106, "image/Move_L_03.bmp", 71, 90);
	SpriteDib.LoadDibSprite(107, "image/Move_L_04.bmp", 71, 90);
	SpriteDib.LoadDibSprite(108, "image/Move_L_05.bmp", 71, 90);
	SpriteDib.LoadDibSprite(109, "image/Move_L_06.bmp", 71, 90);
	SpriteDib.LoadDibSprite(110, "image/Move_L_07.bmp", 71, 90);
	SpriteDib.LoadDibSprite(111, "image/Move_L_08.bmp", 71, 90);
	SpriteDib.LoadDibSprite(112, "image/Move_L_09.bmp", 71, 90);
	SpriteDib.LoadDibSprite(113, "image/Move_L_10.bmp", 71, 90);
	SpriteDib.LoadDibSprite(114, "image/Move_L_11.bmp", 71, 90);
	SpriteDib.LoadDibSprite(115, "image/Move_L_12.bmp", 71, 90);

	// ===========================================================
	// 공격 1
	// ===========================================================
	SpriteDib.LoadDibSprite(16, "image/Attack1_R_01.bmp", 71, 90);
	SpriteDib.LoadDibSprite(17, "image/Attack1_R_02.bmp", 71, 90);
	SpriteDib.LoadDibSprite(18, "image/Attack1_R_03.bmp", 71, 90);
	SpriteDib.LoadDibSprite(19, "image/Attack1_R_04.bmp", 71, 90);

	SpriteDib.LoadDibSprite(116, "image/Attack1_L_01.bmp", 71, 90);
	SpriteDib.LoadDibSprite(117, "image/Attack1_L_02.bmp", 71, 90);
	SpriteDib.LoadDibSprite(118, "image/Attack1_L_03.bmp", 71, 90);
	SpriteDib.LoadDibSprite(119, "image/Attack1_L_04.bmp", 71, 90);

	// ===========================================================
	// 공격 2
	// ===========================================================
	SpriteDib.LoadDibSprite(20, "image/Attack2_R_01.bmp", 71, 90);
	SpriteDib.LoadDibSprite(21, "image/Attack2_R_02.bmp", 71, 90);
	SpriteDib.LoadDibSprite(22, "image/Attack2_R_03.bmp", 71, 90);
	SpriteDib.LoadDibSprite(23, "image/Attack2_R_04.bmp", 71, 90);

	SpriteDib.LoadDibSprite(120, "image/Attack2_L_01.bmp", 71, 90);
	SpriteDib.LoadDibSprite(121, "image/Attack2_L_02.bmp", 71, 90);
	SpriteDib.LoadDibSprite(122, "image/Attack2_L_03.bmp", 71, 90);
	SpriteDib.LoadDibSprite(123, "image/Attack2_L_04.bmp", 71, 90);

	// ===========================================================
	// 공격 3
	// ===========================================================
	SpriteDib.LoadDibSprite(24, "image/Attack3_R_01.bmp", 71, 90);
	SpriteDib.LoadDibSprite(25, "image/Attack3_R_02.bmp", 71, 90);
	SpriteDib.LoadDibSprite(26, "image/Attack3_R_03.bmp", 71, 90);
	SpriteDib.LoadDibSprite(27, "image/Attack3_R_04.bmp", 71, 90);

	SpriteDib.LoadDibSprite(124, "image/Attack3_L_01.bmp", 71, 90);
	SpriteDib.LoadDibSprite(125, "image/Attack3_L_02.bmp", 71, 90);
	SpriteDib.LoadDibSprite(126, "image/Attack3_L_03.bmp", 71, 90);
	SpriteDib.LoadDibSprite(127, "image/Attack3_L_04.bmp", 71, 90);

	SpriteDib.LoadDibSprite(128, "image/xSpark_1.bmp", 71, 90);
	SpriteDib.LoadDibSprite(129, "image/xSpark_2.bmp", 71, 90);
	SpriteDib.LoadDibSprite(130, "image/xSpark_3.bmp", 71, 90);
	SpriteDib.LoadDibSprite(131, "image/xSpark_4.bmp", 71, 90);


	SpriteInfoArr[ACTION_STAND] = CSpriteInfo(1, 3, DELAY_STAND);

	SpriteInfoArr[ACTION_MOVE_RR] = CSpriteInfo(4, 15, DELAY_MOVE);
	SpriteInfoArr[ACTION_MOVE_RU] = CSpriteInfo(4, 15, DELAY_MOVE);
	SpriteInfoArr[ACTION_MOVE_RD] = CSpriteInfo(4, 15, DELAY_MOVE);

	SpriteInfoArr[ACTION_MOVE_LL] = CSpriteInfo(4, 15, DELAY_MOVE);
	SpriteInfoArr[ACTION_MOVE_LU] = CSpriteInfo(4, 15, DELAY_MOVE);
	SpriteInfoArr[ACTION_MOVE_LD] = CSpriteInfo(4, 15, DELAY_MOVE);

	SpriteInfoArr[ACTION_MOVE_UU] = CSpriteInfo(4, 15, DELAY_MOVE);
	SpriteInfoArr[ACTION_MOVE_DD] = CSpriteInfo(4, 15, DELAY_MOVE);

	SpriteInfoArr[ACTION_ATTACK1] = CSpriteInfo(16, 19, DELAY_ATTACK1);
	SpriteInfoArr[ACTION_ATTACK2] = CSpriteInfo(20, 23, DELAY_ATTACK2);
	SpriteInfoArr[ACTION_ATTACK3] = CSpriteInfo(24, 27, DELAY_ATTACK3);
}

void MakeConsole()
{
	AllocConsole();
	freopen("CONOUT$", "wt", stdout);
}

void ReadEvent()
{
	int recvBytes;
	int enqueueBytes;
	char buffer[10000];
	while (1)
	{
		recvBytes = recv(g_Socket, buffer, sizeof(buffer), NULL);

		if (recvBytes == SOCKET_ERROR)
		{
			if (WSAGetLastError() == WSAEWOULDBLOCK)
			{
				return;
			}
			printf("recv 에러\n");
			closesocket(g_Socket);
			return;
		}

		if (recvBytes == 0)
		{
			printf("recvEvent()에러\n");
			closesocket(g_Socket);
			return;
		}

		enqueueBytes = g_RecvQueue.Enqueue(buffer, recvBytes);
		if (enqueueBytes != recvBytes)
		{
			printf("ReadEvent에서 제대로 인큐되지 않았습니다. 종료합니다.\n");
			closesocket(g_Socket);
			return;
		}

		while (1)
		{
			stHEADER header;
			char tempBuffer[1000];

			if (g_RecvQueue.GetUseSize() < sizeof(header))
			{
				//printf("헤더만큼의 데이터도 없습니다.\n");
				return;
			}

			g_RecvQueue.Peek((char*)&header, sizeof(header));

			if (g_RecvQueue.GetUseSize() < sizeof(header) + header.bySize)
			{
				printf("헤더는 들어왔지만 데이터가 아직 다 안들어왔습니다.\n");
				return;
			}
			//헤더크기만큼 옮겨준다
			g_RecvQueue.MoveFront(sizeof(header));
			//tempBuffer에 데이터가 전부 들어왔을것이다.
			g_RecvQueue.Dequeue(tempBuffer, header.bySize);
			PacketProc(header.byType, tempBuffer);
		}
	}
	
}

void PacketProc(int packetType, char* buffer)
{
	switch (packetType)
	{
	case dfPACKET_SC_CREATE_MY_CHARACTER:
		NetPacketProc_CreateMyCharacter(buffer);
		break;
	case dfPACKET_SC_CREATE_OTHER_CHARACTER:
		NetPacketProc_CreateOtherCharacter(buffer);
		break;
	case dfPACKET_SC_DELETE_CHARACTER:
		NetPacketProc_DeleteCharacter(buffer);
		break;
	case dfPACKET_SC_MOVE_START:
		NetPacketProc_SC_MoveStart(buffer);
		break;
	case dfPACKET_SC_MOVE_STOP:
		NetPacketProc_SC_MoveStop(buffer);
		break;
	case dfPACKET_SC_ATTACK1:
		NetPacketProc_SC_Attack1(buffer);
		break;
	case dfPACKET_SC_ATTACK2:
		NetPacketProc_SC_Attack2(buffer);
		break;
	case dfPACKET_SC_ATTACK3:
		NetPacketProc_SC_Attack3(buffer);
		break;
	case dfPACKET_SC_DAMAGE:
		NetPacketProc_Damage(buffer);
		break;
	case dfPACKET_SC_SYNC:
		NetPacketProc_Sync(buffer);
		break;
	}
}

void NetPacketProc_CreateMyCharacter(char* packet)
{
	stPACKET_SC_CREATE_MY_CHARACTER* pPacket = (stPACKET_SC_CREATE_MY_CHARACTER*)packet;
	int dir;
	if (pPacket->direction == dfPACKET_MOVE_DIR_LL)
		dir = DIR_LEFT;
	else
		dir = DIR_RIGHT;

	CBaseObject* myPlayerObject = new CPlayerObject(pPacket->id, dir, pPacket->X, pPacket->Y, pPacket->hp);
	g_pPlayerObject = myPlayerObject;
	
	g_ObjectList.push_front(myPlayerObject);
}

void NetPacketProc_CreateOtherCharacter(char* packet)
{
	stPACKET_SC_CREATE_OTHER_CHARACTER* pPacket = (stPACKET_SC_CREATE_OTHER_CHARACTER*)packet;
	int dir;
	if (pPacket->direction == dfPACKET_MOVE_DIR_LL)
		dir = DIR_LEFT;
	else
		dir = DIR_RIGHT;

	CBaseObject* otherPlayerObject = new CPlayerObject(pPacket->id, dir, pPacket->X, pPacket->Y, pPacket->hp);
	
	g_ObjectList.push_front(otherPlayerObject);
}
void NetPacketProc_DeleteCharacter(char* packet)
{
	stPACKET_SC_DELETE_CHARACTER* pPacket = (stPACKET_SC_DELETE_CHARACTER*)packet;
	
	for (CList<CBaseObject*>::iterator itor = g_ObjectList.begin(); itor != g_ObjectList.end(); itor++)
	{
		if (itor->_data->GetObjectID() != pPacket->id)
			continue;
		//하나만 삭제 할것이기때문에 erase에서 다음 이터레이터를 리턴받지않음
		g_ObjectList.erase(itor);
		break;
	}
}
void NetPacketProc_SC_MoveStart(char* packet)
{
	stPACKET_SC_MOVE_START* pPacket = (stPACKET_SC_MOVE_START*)packet;
	for (CList<CBaseObject*>::iterator itor = g_ObjectList.begin(); itor != g_ObjectList.end(); itor++)
	{
		if (itor->_data->GetObjectID() != pPacket->id)
			continue;

		itor->_data->ActionInput(pPacket->direction);
		break;
	}
}
void NetPacketProc_SC_MoveStop(char* packet)
{
	stPACKET_SC_MOVE_STOP* pPacket = (stPACKET_SC_MOVE_STOP*)packet;
	for (CList<CBaseObject*>::iterator itor = g_ObjectList.begin(); itor != g_ObjectList.end(); itor++)
	{
		if (itor->_data->GetObjectID() != pPacket->id)
			continue;

		itor->_data->ActionInput(ACTION_STAND);
		if(pPacket->direction == dfPACKET_MOVE_DIR_LL)
			((CPlayerObject*)itor->_data)->SetDirection(DIR_LEFT);
		else
			((CPlayerObject*)itor->_data)->SetDirection(DIR_RIGHT);

		itor->_data->SetPosition(pPacket->X, pPacket->Y);

		break;
	}
}
void NetPacketProc_SC_Attack1(char* packet)
{
	stPACKET_SC_ATTACK1* pPacket = (stPACKET_SC_ATTACK1*)packet;

	for (CList<CBaseObject*>::iterator itor = g_ObjectList.begin(); itor != g_ObjectList.end(); itor++)
	{
		if (itor->_data->GetObjectID() != pPacket->id)
			continue;

		itor->_data->ActionInput(ACTION_ATTACK1);
		if (pPacket->direction == dfPACKET_MOVE_DIR_LL)
			((CPlayerObject*)itor->_data)->SetDirection(DIR_LEFT);
		else
			((CPlayerObject*)itor->_data)->SetDirection(DIR_RIGHT);
		break;
	}
}
void NetPacketProc_SC_Attack2(char* packet)
{
	stPACKET_SC_ATTACK2* pPacket = (stPACKET_SC_ATTACK2*)packet;

	for (CList<CBaseObject*>::iterator itor = g_ObjectList.begin(); itor != g_ObjectList.end(); itor++)
	{
		if (itor->_data->GetObjectID() != pPacket->id)
			continue;

		itor->_data->ActionInput(ACTION_ATTACK2);
		if (pPacket->direction == dfPACKET_MOVE_DIR_LL)
			((CPlayerObject*)itor->_data)->SetDirection(DIR_LEFT);
		else
			((CPlayerObject*)itor->_data)->SetDirection(DIR_RIGHT);
		break;
	}
}
void NetPacketProc_SC_Attack3(char* packet)
{
	stPACKET_SC_ATTACK3* pPacket = (stPACKET_SC_ATTACK3*)packet;

	for (CList<CBaseObject*>::iterator itor = g_ObjectList.begin(); itor != g_ObjectList.end(); itor++)
	{
		if (itor->_data->GetObjectID() != pPacket->id)
			continue;

		itor->_data->ActionInput(ACTION_ATTACK3);
		if (pPacket->direction == dfPACKET_MOVE_DIR_LL)
			((CPlayerObject*)itor->_data)->SetDirection(DIR_LEFT);
		else
			((CPlayerObject*)itor->_data)->SetDirection(DIR_RIGHT);
		break;
	}
}
void NetPacketProc_Damage(char* packet)
{
	printf("데미지 프로시저\n");
	stPACKET_SC_DAMAGE* pPacket = (stPACKET_SC_DAMAGE*)packet;

	for (CList<CBaseObject*>::iterator itor = g_ObjectList.begin(); itor != g_ObjectList.end(); itor++)
	{
		if (itor->_data->GetObjectID() != pPacket->damageID)
			continue;

		((CPlayerObject*)(itor->_data))->SetHp(pPacket->damageHP);

		if(g_pPlayerObject->GetActionInput() == ACTION_ATTACK3)
			g_EffectList.push_front(new CEffectObject(itor->_data->GetCurX(), itor->_data->GetCurY(), TRUE));
		else
			g_EffectList.push_front(new CEffectObject(itor->_data->GetCurX(), itor->_data->GetCurY(), FALSE));

		break;
	}
}
void NetPacketProc_Sync(char* packet)
{
	printf("씽크메시지\n");
}

void SendEvent()
{

}

void WriteEvent()
{
	char packet[1000];
	int dequeueSize;
	int sendSize;
	while (1)
	{
		if (g_SendQueue.GetUseSize() == 0)
			break;

		dequeueSize = g_SendQueue.Peek(packet, sizeof(packet));

		sendSize = send(g_Socket, packet, dequeueSize, NULL);

		if (sendSize == SOCKET_ERROR)
		{
			if (WSAGetLastError() == WSAEWOULDBLOCK)
			{
				g_SendFlag = false;
				return;
			}
			printf("send도중 에러가 발생했습니다.\n");
			closesocket(g_Socket);
			return;
		}

		g_SendQueue.MoveFront(sendSize);
	}
}