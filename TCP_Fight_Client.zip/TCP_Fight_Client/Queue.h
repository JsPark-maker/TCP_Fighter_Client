#pragma once
#define QUEUE_SIZE 5

template<typename T>
class CQueue
{
public:
	// ==========================
	// ������
	// ==========================
	CQueue() = default;

	// ==========================
	// �Ҹ���
	// ==========================
	~CQueue() = default;

	// ==========================
	// IsEmpty
	// ==========================
	bool IsEmpty();

	// ==========================
	// IsFull
	// ==========================
	bool IsFull();

	// ==========================
	// EnQueue
	// ==========================
	bool EnQueue(T data);

	// ==========================
	// DeQueue
	// ==========================
	bool DeQueue(T* data);

	// ==========================
	// Peek
	// ==========================
	T Peek();

private:
	T QueueArr[QUEUE_SIZE];
	int front = 0;
	int rear = 0;

};

template<typename T>
inline bool CQueue<T>::IsEmpty()
{
	if (front == rear) return true;
	return false;
}

template<typename T>
inline bool CQueue<T>::IsFull()
{
	if ((rear + 1) % QUEUE_SIZE == front) return true;
	return false;
}

template<typename T>
inline bool CQueue<T>::EnQueue(T data)
{
	if (IsFull()) return false;
	QueueArr[rear] = data;
	rear = (rear + 1) % QUEUE_SIZE;
	return true;
}

template<typename T>
inline bool CQueue<T>::DeQueue(T* data)
{
	if (IsEmpty()) return false;
	*data = QueueArr[front];
	front = (front + 1) % QUEUE_SIZE;
	return true;
}

template<typename T>
inline T CQueue<T>::Peek()
{
	return QueueArr[front];
}
