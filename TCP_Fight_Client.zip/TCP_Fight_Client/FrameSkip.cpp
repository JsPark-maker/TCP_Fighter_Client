#pragma comment (lib, "Winmm")
#include <Windows.h>
#include "FrameSkip.h"

CFrameSkip::CFrameSkip(int _MaxFrameTime)
	:_MaxFrameTime(_MaxFrameTime)
{}

bool CFrameSkip::FrameSkip(HWND hWnd)
{
	//static DWORD logicOldTime = timeGetTime();
	//static DWORD logicFrame = 0;
	//logicFrame++;

	static DWORD oldTime = timeGetTime();
	DWORD		 nowTime = timeGetTime();

	// �� frame �ɸ��� �ð�
	_OneFrameTime += nowTime - oldTime;

	// LogicFrame ���
	//if (nowTime - logicOldTime > 1000)
	//{
	//	WCHAR FrameText[20];
	//	wsprintf(FrameText, L"Logic_FPS = %d", logicFrame);
	//	SetWindowText(hWnd, FrameText);
	//	logicOldTime = timeGetTime();
	//	logicFrame = 0;
	//}

	if (_OneFrameTime < _MaxFrameTime) // 26
	{
		Sleep(_MaxFrameTime - _OneFrameTime); // ( �̻��� ������ oldTime ���� timeGetTime�� ����ϸ� �ȵ� )
		oldTime = nowTime + (_MaxFrameTime - _OneFrameTime); // oldTime ���� 
		_OneFrameTime = 0;
	}
	else
	{
		_OneFrameTime -= _MaxFrameTime; // 26 - 20 = 6 ( oneFrameTime�� ���� ) 

		oldTime = timeGetTime();

		if (_OneFrameTime >= _MaxFrameTime)
		{
			_OneFrameTime -= _MaxFrameTime;
			return false;
		}
	}

	return true;
}