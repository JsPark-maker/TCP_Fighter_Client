#pragma once
class CEffectObject : public CBaseObject
{
public:
	CEffectObject(int X, int Y, bool isLateEffect);
	virtual ~CEffectObject() = default;
public:
	int X;
	int Y;
	int lateDelayCount;
	bool isLateEffect;
	void Render(BYTE* pDest, int DestWidth, int DestHeight, int DestPitch) override;
	void Update() override;
};

extern CSpriteDib SpriteDib;
