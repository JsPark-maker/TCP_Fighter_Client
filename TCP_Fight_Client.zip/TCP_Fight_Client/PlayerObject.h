#pragma once
#define ACTION_MOVE_LL		0
#define ACTION_MOVE_LU		1
#define ACTION_MOVE_UU		2
#define ACTION_MOVE_RU		3
#define ACTION_MOVE_RR		4
#define ACTION_MOVE_RD		5
#define ACTION_MOVE_DD		6
#define ACTION_MOVE_LD		7

#define ACTION_PUSH			11
#define ACTION_STAND		12

#define ACTION_ATTACK1		8
#define ACTION_ATTACK2		9
#define ACTION_ATTACK3		10

#define SHADOW				100
#define GUAGE_HP			500

#define RANGE_MOVE_TOP		50
#define RANGE_MOVE_LEFT		10
#define RANGE_MOVE_RIGHT	630
#define RANGE_MOVE_BOTTOM	470


#define DIR_RIGHT			1
#define DIR_LEFT			2

#define DELAY_STAND			5
#define DELAY_MOVE			4
#define DELAY_ATTACK1		3
#define DELAY_ATTACK2		4
#define DELAY_ATTACK3		4
#define DELAY_EFFECT		3

extern SOCKET g_Socket;
extern CRingBuffer g_RecvQueue;
extern CRingBuffer g_SendQueue;
extern CBaseObject* g_pPlayerObject;
extern bool g_SendFlag;
extern void WriteEvent();

class CPlayerObject : public CBaseObject
{
public:
	// ==========================
	// ������
	// ==========================
	CPlayerObject() = default;
	CPlayerObject(unsigned int id, unsigned char dir, unsigned short X, unsigned short Y, unsigned char hp);
	// ==========================
	// �Ҹ���
	// ==========================
	virtual ~CPlayerObject() = default;
	
private:
	bool _playerCharacter;
	char _hp;
	//��ó���� ACTION_STAND�� ��Ƽ� ���ְ�����
	DWORD _actionCur = ACTION_STAND;
	DWORD _actionOld;
	int _dirCur;
	int _dirOld;

public:
	void ActionProc();

	int GetDirection();

	int GetHP();

	void InputActionProc();

	bool IsPlayer();

	virtual void Render(BYTE *pDest, int DestWidth, int DestHeight, int DestPitch);

	virtual void Update();

	void SetActionAttack1();

	void SetActionAttack2();

	void SetActionAttack3();

	void SetActionMove();

	void SetActionStand();

	void SetDirection(int dir);

	void SetHp(int hp);

	void SendProc(int action);

	void SendPacket_MoveStart(stHEADER* pHeader, char* pPacket, int dir, int X, int Y);

	void SendPacket_MoveStop(stHEADER* pHeader, char* pPacket, int dir, int X, int Y);

	void SendPacket_Attack1(stHEADER* pHeader, char* pPacket, int dir, int X, int Y);

	void SendPacket_Attack2(stHEADER* pHeader, char* pPacket, int dir, int X, int Y);

	void SendPacket_Attack3(stHEADER* pHeader, char* pPacket, int dir, int X, int Y);

};

extern CSpriteDib SpriteDib;
extern CSpriteInfo SpriteInfoArr[20];