#pragma once
class CScreenDibBuffer
{
public:
	// =========================
	// ������
	// =========================
	CScreenDibBuffer(int Width, int Height, int BitColor);

	// =========================
	// �Ҹ���
	// =========================
	~CScreenDibBuffer();

	// =========================
	// CreateDibBuffer
	// =========================
	void CreateDibBuffer(void);

	void Flip(HWND hWnd);

	BYTE* GetScreenBuffer(void);

	int GetHieght(void);

	int GetWidth(void);

	int GetPitch(void);

	void ShowFrame(HWND hWnd);

private:
	BITMAPINFO _DivInfoHeader;
	BYTE*	_pScreenBuffer;

	int		_BitColor;
	int		_Height;
	int		_Width;
	int		_Pitch;
};

