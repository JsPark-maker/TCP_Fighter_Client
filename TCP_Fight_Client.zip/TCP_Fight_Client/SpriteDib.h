#pragma once
class CSpriteDib
{
public:
	// =======================
	// Sprite ����ü
	// =======================
	struct _stSprite
	{
		BYTE* _pBitMapImage;
		int _BitColor;
		int _Width;
		int _Height;
		int _Pitch;
		int _Size;

		int _CenterPointX;
		int _CenterPointY;
	};

	// =======================
	// ������
	// =======================
	CSpriteDib(int MaxSprite, DWORD ColorKey);

	// =======================
	// �Ҹ���
	// =======================
	~CSpriteDib();

	BOOL LoadDibSprite(int SpriteIndex, const char* FileName, int CenterPointX, int CenterPointY);

	void ReleaseSprite(int SpriteIndex);

	void DrawSprite(int SpriteIndex, int DrawX, int DrawY, BYTE* pDest, int DestWidth, int DestHeight, int DestPitch, int DrawLen = 100);

	void DrawImage(int SpriteIndex, int DrawX, int DrawY, BYTE* pDest, int DestWidth, int DestHeight, int DestPitch, int DrawLen = 100);
private:   

	int			_MaxSprite;
	_stSprite*	_stpSprite;

	DWORD _ColorKey;
};

