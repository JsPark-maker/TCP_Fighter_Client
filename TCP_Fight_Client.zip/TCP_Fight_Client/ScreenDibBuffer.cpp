#include "framework.h"
#include "DibBuferr.h"
#include "ScreenDibBuffer.h"

CScreenDibBuffer::CScreenDibBuffer(int Width, int Height, int BitColor)
	:_Height(Height), _Width(Width), _BitColor(BitColor)
{
	_Pitch = (Width * (BitColor / 8)) + 3 & ~3;

	_DivInfoHeader.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	_DivInfoHeader.bmiHeader.biBitCount = BitColor;
	_DivInfoHeader.bmiHeader.biWidth = Width;
	_DivInfoHeader.bmiHeader.biHeight = -Height;
	_DivInfoHeader.bmiHeader.biPlanes = 1;
	_DivInfoHeader.bmiHeader.biCompression = BI_RGB;

	CreateDibBuffer();
}

CScreenDibBuffer::~CScreenDibBuffer()
{
	delete[] _pScreenBuffer;
}

void CScreenDibBuffer::CreateDibBuffer(void)
{
	_pScreenBuffer = new BYTE[_Height * _Pitch];
}

void CScreenDibBuffer::Flip(HWND hWnd)
{
	HDC hdc = GetDC(hWnd);
	StretchDIBits(hdc, 0, 0, _Width, _Height, 0, 0, _Width, _Height, 
		_pScreenBuffer, &_DivInfoHeader, DIB_RGB_COLORS, SRCCOPY);
	ReleaseDC(hWnd, hdc);
	ShowFrame(hWnd);
}

BYTE* CScreenDibBuffer::GetScreenBuffer(void)
{
	return _pScreenBuffer;
}

int CScreenDibBuffer::GetHieght(void)
{
	return _Height;
}

int CScreenDibBuffer::GetWidth(void)
{
	return _Width;
}

int CScreenDibBuffer::GetPitch(void)
{
	return _Pitch;
}

void CScreenDibBuffer::ShowFrame(HWND hWnd)
{
	static DWORD frame = 50;
	static DWORD frameCount = 0;

	frameCount++;

	static DWORD StartTime = GetTickCount();
	if (GetTickCount() - StartTime > 1000)
	{
		frame = frameCount;
		frameCount = 0;
		StartTime = GetTickCount();
	}

	WCHAR FrameText[3];
	wsprintf(FrameText, L"%d", frame);

	HDC hdc = GetDC(hWnd);
	TextOut(hdc, 0, 0, FrameText, wcslen(FrameText));
	ReleaseDC(hWnd, hdc);
}
